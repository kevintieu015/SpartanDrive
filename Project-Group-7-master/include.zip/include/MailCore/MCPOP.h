#ifndef MAILCORE_MCPOP_H

#define MAILCORE_MCPOP_H

#include <MailCore/MCPOPMessageInfo.h>
#include <MailCore/MCPOPProgressCallback.h>
#include <MailCore/MCPOPSession.h>

#endif
