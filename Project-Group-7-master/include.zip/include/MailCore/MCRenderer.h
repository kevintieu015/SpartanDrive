//
//  MCRenderer.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 2/2/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef MAILCORE_MCRENDERER_H

#define MAILCORE_MCRENDERER_H

#include <MailCore/MCHTMLRendererCallback.h>
#include <MailCore/MCDateFormatter.h>
#include <MailCore/MCAddressDisplay.h>

#endif
