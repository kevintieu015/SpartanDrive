#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseDatabase : NSObject
@end
@implementation PodsDummy_FirebaseDatabase
@end
