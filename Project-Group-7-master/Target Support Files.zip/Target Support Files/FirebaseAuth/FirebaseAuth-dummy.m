#import <Foundation/Foundation.h>
@interface PodsDummy_FirebaseAuth : NSObject
@end
@implementation PodsDummy_FirebaseAuth
@end
