#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_Project_Group_7 : NSObject
@end
@implementation PodsDummy_Pods_Project_Group_7
@end
